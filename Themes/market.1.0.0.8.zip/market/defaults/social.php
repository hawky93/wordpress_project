<div id="social-icons" class="col-md-5 col-xs-12">
				 <a target="_blank" href="#" title="Facebook" ><img src="<?php echo get_template_directory_uri()."/images/social/default/facebook.png"; ?>"></a>
				 <a target="_blank" href="#" title="Twitter" ><img src="<?php echo get_template_directory_uri()."/images/social/default/twitter.png"; ?>"></a>
	             <a target="_blank" href="#" title="Google Plus" ><img src="<?php echo get_template_directory_uri()."/images/social/default/google.png"; ?>"></a>
				 <a target="_blank" href="#" title="RSS Feeds" ><img src="<?php echo get_template_directory_uri()."/images/social/default/rss.png"; ?>"></a>
				 <a target="_blank" href="#" title="Instagram" ><img src="<?php echo get_template_directory_uri()."/images/social/default/instagram.png"; ?>"></a>
				 <a target="_blank" href="#" title="Flickr" ><img src="<?php echo get_template_directory_uri()."/images/social/default/flickr.png"; ?>"></a>
	             <a target="_blank" href="#" title="Linked In" ><img src="<?php echo get_template_directory_uri()."/images/social/default/linkedin.png"; ?>"></a>
	             <a target="_blank" href="#" title="Pinterest" ><img src="<?php echo get_template_directory_uri()."/images/social/default/pinterest.png"; ?>"></a>
	             <a target="_blank" href="#" title="YouTube" ><img src="<?php echo get_template_directory_uri()."/images/social/default/youtube.png"; ?>"></a>
</div> 