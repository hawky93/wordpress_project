<div class="slider-wrapper theme-default container"> 
	<div class="ribbon"></div>    
		<div id="slider" class="nivoSlider">
				<a href='#'><img src='<?php echo get_template_directory_uri()."/defaults/images/dimg9.jpg"; ?>' title='#caption_1'></a> 
				<a href='#'><img src='<?php echo get_template_directory_uri()."/defaults/images/dimg8.jpg"; ?>' title='#caption_2'></a> 	 
		</div><!--#slider-->
    				<div id='caption_1' class='nivo-html-caption'><div class='nivocapper'>
    				<a href='#'><div class='slide-title'>Fully Responsive Theme</div></a>
    				<div class='slide-description'>Resize your Browser to see the Effect</div>
    				</div></div>
    				<div id='caption_2' class='nivo-html-caption'><div class='nivocapper'>
    				<a href='#'><div class='slide-title'>Retina Ready</div></a>
    				<div class='slide-description'>Looks Beautiful on Retina Displays</div>
    				</div></div>
</div>	