<?php

namespace OpenCloud\Common\Exceptions;

class MissingValueError extends \Exception {}
