<?php

namespace OpenCloud\Common\Exceptions;

class InvalidArgumentError extends \Exception {}
