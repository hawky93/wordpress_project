<?php

namespace OpenCloud\Common\Exceptions;

class ContainerNotEmptyError extends \Exception {}
