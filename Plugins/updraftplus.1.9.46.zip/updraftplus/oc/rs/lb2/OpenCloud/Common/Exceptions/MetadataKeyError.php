<?php

namespace OpenCloud\Common\Exceptions;

class MetadataKeyError extends \Exception {}
