<?php

namespace OpenCloud\Common\Exceptions;

class TempUrlMethodError extends \Exception {}
