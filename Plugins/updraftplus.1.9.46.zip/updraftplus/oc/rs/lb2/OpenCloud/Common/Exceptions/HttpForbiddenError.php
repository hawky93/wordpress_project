<?php

namespace OpenCloud\Common\Exceptions;

class HttpForbiddenError extends \Exception {}
