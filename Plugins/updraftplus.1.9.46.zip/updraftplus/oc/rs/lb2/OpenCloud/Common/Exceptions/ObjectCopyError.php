<?php

namespace OpenCloud\Common\Exceptions;

class ObjectCopyError extends \Exception {}
