<?php

namespace OpenCloud\Common\Exceptions;

class MetadataDeleteError extends \Exception {}
